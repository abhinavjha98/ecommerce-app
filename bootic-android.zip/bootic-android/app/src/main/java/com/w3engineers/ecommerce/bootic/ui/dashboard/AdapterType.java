package com.w3engineers.ecommerce.bootic.ui.dashboard;

public enum AdapterType {
    FEATURE,
    RECENT,
    POPULAR
}
