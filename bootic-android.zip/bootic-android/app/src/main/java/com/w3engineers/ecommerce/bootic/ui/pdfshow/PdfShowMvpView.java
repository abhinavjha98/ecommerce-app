package com.w3engineers.ecommerce.bootic.ui.pdfshow;

import com.w3engineers.ecommerce.bootic.data.helper.base.MvpView;

public interface PdfShowMvpView  extends MvpView {
}
