package com.w3engineers.ecommerce.bootic.data.helper.models;

public class EncryptionModel {
    public String method;
    public String amount;
    public String ordered_products;
    public String address;
    public String user;
    public String api_token;


}
