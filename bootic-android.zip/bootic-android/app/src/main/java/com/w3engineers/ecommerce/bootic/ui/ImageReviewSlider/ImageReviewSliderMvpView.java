package com.w3engineers.ecommerce.bootic.ui.ImageReviewSlider;

import com.w3engineers.ecommerce.bootic.data.helper.base.MvpView;

public interface ImageReviewSliderMvpView  extends MvpView {
}
