package com.w3engineers.ecommerce.bootic.ui.setting;


import com.w3engineers.ecommerce.bootic.data.helper.base.MvpView;

public interface SettingMvpView extends MvpView {
}
