package com.w3engineers.ecommerce.bootic.ui.productdetails;

import android.view.View;

import com.w3engineers.ecommerce.bootic.data.helper.models.ProductDetailsImageModel;

public interface ItemClickReviewImage {
    void onItemClick(View v,ProductDetailsImageModel item, int i);
}
