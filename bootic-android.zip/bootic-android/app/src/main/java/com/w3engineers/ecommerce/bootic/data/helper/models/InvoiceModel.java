package com.w3engineers.ecommerce.bootic.data.helper.models;

import java.util.List;

public class InvoiceModel {
    public List<CustomProductInventory> inventoryListForInvoice;
}
