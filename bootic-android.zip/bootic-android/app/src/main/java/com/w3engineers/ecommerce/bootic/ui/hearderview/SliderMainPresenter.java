package com.w3engineers.ecommerce.bootic.ui.hearderview;

import com.w3engineers.ecommerce.bootic.data.helper.base.BasePresenter;

public class SliderMainPresenter extends BasePresenter<SliderMainMvpView> {
}
