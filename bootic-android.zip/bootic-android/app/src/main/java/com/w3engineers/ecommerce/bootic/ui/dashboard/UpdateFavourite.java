package com.w3engineers.ecommerce.bootic.ui.dashboard;

public interface UpdateFavourite {
    void updateFavourite(int status);
}
