package com.w3engineers.ecommerce.bootic.ui.privacy_policy;


import com.w3engineers.ecommerce.bootic.data.helper.base.BasePresenter;

public class PrivacyPolicyPresenter extends BasePresenter<PrivacyPolicyMvpView> {
}
