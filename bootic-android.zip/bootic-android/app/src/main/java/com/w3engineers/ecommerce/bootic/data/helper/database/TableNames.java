package com.w3engineers.ecommerce.bootic.data.helper.database;

public interface TableNames {
    String CODES = "CART";
}
