package com.w3engineers.ecommerce.bootic.ui.productdetails;

import com.w3engineers.ecommerce.bootic.data.helper.models.InterestedProductModel;

public interface InterestItemClick {
    void onClickListener(InterestedProductModel mModel, int position);
}
