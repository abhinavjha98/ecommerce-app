package com.w3engineers.ecommerce.bootic.ui.setting;


import com.w3engineers.ecommerce.bootic.data.helper.base.BasePresenter;

public class SettingPresenter extends BasePresenter<SettingMvpView> {
}
