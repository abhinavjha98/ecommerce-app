package com.w3engineers.ecommerce.bootic.ui.welcome;

import com.w3engineers.ecommerce.bootic.data.helper.base.BasePresenter;

public class WelcomePresenter extends BasePresenter<WelcomeMvpView> {
}
