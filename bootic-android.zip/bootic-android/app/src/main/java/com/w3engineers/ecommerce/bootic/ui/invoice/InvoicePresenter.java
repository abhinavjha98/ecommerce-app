package com.w3engineers.ecommerce.bootic.ui.invoice;

import com.w3engineers.ecommerce.bootic.data.helper.base.BasePresenter;

public class InvoicePresenter extends BasePresenter<InvoiceMvpView> {
}
