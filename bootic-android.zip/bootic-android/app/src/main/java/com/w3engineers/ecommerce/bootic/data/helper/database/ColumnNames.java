package com.w3engineers.ecommerce.bootic.data.helper.database;

public interface ColumnNames {
    String ID = "id";
}
