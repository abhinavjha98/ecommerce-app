package com.w3engineers.ecommerce.bootic.ui.aboutus;

import com.w3engineers.ecommerce.bootic.data.helper.base.MvpView;

public interface AboutUsMvpView extends MvpView {
}
