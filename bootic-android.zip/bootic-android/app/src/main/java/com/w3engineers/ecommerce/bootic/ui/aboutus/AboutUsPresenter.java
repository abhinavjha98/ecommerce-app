package com.w3engineers.ecommerce.bootic.ui.aboutus;

import com.w3engineers.ecommerce.bootic.data.helper.base.BasePresenter;

public class AboutUsPresenter extends BasePresenter<AboutUsMvpView> {
}
