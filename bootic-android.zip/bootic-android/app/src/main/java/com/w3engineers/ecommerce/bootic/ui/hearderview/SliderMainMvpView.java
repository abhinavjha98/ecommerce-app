package com.w3engineers.ecommerce.bootic.ui.hearderview;

import com.w3engineers.ecommerce.bootic.data.helper.base.MvpView;

public interface SliderMainMvpView extends MvpView {
}
