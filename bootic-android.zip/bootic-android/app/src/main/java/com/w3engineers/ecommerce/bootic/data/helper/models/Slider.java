package com.w3engineers.ecommerce.bootic.data.helper.models;

import java.util.ArrayList;

public class Slider {
    public ArrayList<SliderMain> mSliderMains;
}
