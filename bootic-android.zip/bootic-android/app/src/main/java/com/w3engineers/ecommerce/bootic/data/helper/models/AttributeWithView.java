package com.w3engineers.ecommerce.bootic.data.helper.models;

import android.view.View;

public class AttributeWithView {
    public View view;
    public int id;

    public AttributeWithView(View view, int id) {
        this.view = view;
        this.id = id;
    }
}
