package com.w3engineers.ecommerce.bootic.ui.welcome;

import com.w3engineers.ecommerce.bootic.data.helper.base.MvpView;

public interface WelcomeMvpView extends MvpView {
}
