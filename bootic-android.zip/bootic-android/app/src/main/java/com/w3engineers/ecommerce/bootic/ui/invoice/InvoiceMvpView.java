package com.w3engineers.ecommerce.bootic.ui.invoice;

import com.w3engineers.ecommerce.bootic.data.helper.base.MvpView;

public interface InvoiceMvpView extends MvpView {
}
