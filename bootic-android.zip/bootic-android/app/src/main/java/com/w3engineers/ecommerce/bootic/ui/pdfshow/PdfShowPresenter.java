package com.w3engineers.ecommerce.bootic.ui.pdfshow;

import com.w3engineers.ecommerce.bootic.data.helper.base.BasePresenter;

public class PdfShowPresenter  extends BasePresenter<PdfShowMvpView> {
}
