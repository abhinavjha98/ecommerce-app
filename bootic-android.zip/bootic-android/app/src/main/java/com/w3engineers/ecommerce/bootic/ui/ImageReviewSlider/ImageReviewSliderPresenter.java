package com.w3engineers.ecommerce.bootic.ui.ImageReviewSlider;

import com.w3engineers.ecommerce.bootic.data.helper.base.BasePresenter;

public class ImageReviewSliderPresenter extends BasePresenter<ImageReviewSliderMvpView> {
}
